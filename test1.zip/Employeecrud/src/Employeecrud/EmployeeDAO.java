package Employeecrud;
import java.sql.*;
import java.util.*;
public class EmployeeDAO {


// Fetch all employees from DB
public List<Employee> getAllEmployees() {
    List<Employee> employees = new ArrayList<>();
    String query = "SELECT * FROM employees";

    try (Connection conn = DBUtil.getConnection();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(query)) {

        while (rs.next()) {
            employees.add(new Employee(
                  //  rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("department"),
                    rs.getDouble("salary")
            ));
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
    return employees;
}

// Insert new employee
public void insertEmployee(Employee employee) {
    String query = "INSERT INTO employees(name, department, salary) VALUES(?,?,?)";
    try (Connection conn = DBUtil.getConnection();
         PreparedStatement ps = conn.prepareStatement(query)) {

        ps.setString(1, employee.getName());
        ps.setString(2, employee.getDepartment());
        ps.setDouble(3, employee.getSalary());
        ps.executeUpdate();

        System.out.println("✅ Employee inserted into DB.");

    } catch (SQLException e) {
        e.printStackTrace();
    }
}

// Update salary of an employee
public void updateEmployeeSalary(int id, double newSalary) {
    String query = "UPDATE employees SET salary=? WHERE id=?";
    try (Connection conn = DBUtil.getConnection();
         PreparedStatement ps = conn.prepareStatement(query)) {

        ps.setDouble(1, newSalary);
        ps.setInt(2, id);
        ps.executeUpdate();

        System.out.println("✅ Salary updated in DB.");

    } catch (SQLException e) {
        e.printStackTrace();
    }
}

// Delete employee
public void deleteEmployee(int id) {
    String query = "DELETE FROM employees WHERE id=?";
    try (Connection conn = DBUtil.getConnection();
         PreparedStatement ps = conn.prepareStatement(query))
    {

        ps.setInt(1, id);
        ps.executeUpdate();

        System.out.println("✅ Employee deleted from DB.");
    }

  

    catch (SQLException e) {
        e.printStackTrace();
    }
}
}