package Employeecrud;
import java.util.*;
public class EmployeeApp {
	  public static void main(String[] args) {
		  EmployeeDAO dao = new EmployeeDAO();

	        // 1. Load employees from DB into List
	        List<Employee> employees = dao.getAllEmployees();

	        // 2. Initialize service with the list
	        EmployeeService service = new EmployeeService(employees);

//	        // 3. Perform operations
//	        System.out.println("🔹 Sorted by Salary Desc:");
//	        service.displayEmployees(service.sortBySalaryDesc());
//
//	        System.out.println("🔹 Employees in IT Department:");
//	        service.displayEmployees(service.searchByDepartment("IT"));
// 
//	        System.out.println("🔹 Employees with salary > 60000:");
//	        service.displayEmployees(service.filterBySalary(60000));

	        // 4. Add new employee
	        Employee newEmp = new Employee( "John", "HR", 65000);
	        service.addEmployee(newEmp, dao);
	        

//	        // 5. Update salary
//	        service.updateSalary(2, 90000, dao);
//
//	        // 6. Remove employee
//	        service.removeEmployee(3, dao);
//
//	        // 7. Group by department
//	     // 7. Group by department
//	        System.out.println("🔹 Grouped by Department:");
//	        service.groupByDepartment().forEach((dept, list) -> {
//	            System.out.println("Department: " + dept);
//	            service.displayEmployees(list);
//	        });
	  }
	}
