package Employeecrud;

import java.util.*;
import java.util.stream.Collectors;

public class EmployeeService {
	  private List<Employee> employees;

	    public EmployeeService(List<Employee> employees) {
	        this.employees = employees;
	    }

	    // Sort employees by salary (desc)
	    public List<Employee> sortBySalaryDesc() {
	        return employees.stream()
	                .sorted(Comparator.comparingDouble(Employee::getSalary).reversed())
	                .collect(Collectors.toList());
	    }

	    // Search employees by department
	    public List<Employee> searchByDepartment(String dept) {
	        return employees.stream()
	                .filter(e -> e.getDepartment().equalsIgnoreCase(dept))
	                .collect(Collectors.toList());
	    }

	    // Filter employees above a salary
	    public List<Employee> filterBySalary(double minSalary) {
	        return employees.stream()
	                .filter(e -> e.getSalary() > minSalary)
	                .collect(Collectors.toList());
	    }

	    // Group employees by department
	    public Map<String, List<Employee>> groupByDepartment() {
	        return employees.stream()
	                .collect(Collectors.groupingBy(Employee::getDepartment));
	    }

	    // Add new employee (collection + DB)
	    public void addEmployee(Employee employee, EmployeeDAO dao) {
	        dao.insertEmployee(employee);
	        employees.add(employee);
	        System.out.println("✅ Employee added in collection & DB.");
	    }

	    // Update employee salary (collection + DB)
	    public void updateSalary(int id, double newSalary, EmployeeDAO dao) {
	        dao.updateEmployeeSalary(id, newSalary);
	        employees.stream()
	                .filter(e -> e.getId() == id)
	                .forEach(e -> e.setSalary(newSalary));
	        System.out.println("✅ Salary updated in collection & DB.");
	    }

	    // Remove employee (collection + DB)
	    public void removeEmployee(int id, EmployeeDAO dao) {
	        dao.deleteEmployee(id);
	        employees.removeIf(e -> e.getId() == id);
	        System.out.println("✅ Employee removed from collection & DB.");
	    }

	    // Display all employees
	    public void displayEmployees(List<Employee> list) {
	        if (list.isEmpty()) {
	            System.out.println("No employees found.");
	        } else {
	            list.forEach(System.out::println);
	        }
	        System.out.println("--------------------------------------------------");
	    }

	}