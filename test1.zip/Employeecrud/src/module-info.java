/**
 * 
 */
/**
 * 
 */
module your.module.name {
    requires java.sql;
}
